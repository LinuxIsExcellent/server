var searchData=
[
  ['mainpage_2etxt',['mainpage.txt',['../mainpage_8txt.html',1,'']]]
];
